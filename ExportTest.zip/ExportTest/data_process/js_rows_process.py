import time
class Js_Rows_Process(object):
    def __init__(self,module_list,j,driver):
        self.module_list=module_list
        self.j=j
        self.driver=driver
    #奇数行数据处理
    def js_rows_process(self):
        #奇数行、非空数据处理
        module_name=self.module_list[self.j]
        try:
            self.driver.find_element_by_xpath('//*[@id="content"]/ul/li[{}]/a'.format((self.j)+1)).click()
        except:
            pass
        try:
            self.driver.find_element_by_xpath('//*[@id="myTab"]/li[{}]/a'.format((self.j)+1)).click()
        except:
            pass
        try:
            self.driver.find_element_by_xpath('//*[@class="content"]/div[1]/a[{}]'.format((self.j)+1)).click()
        except:
            pass
        time.sleep(1)
        return module_name
    #重构后模块奇数行后有iframe切换
    def js_rows_process_new(self):
        #奇数行、非空数据处理
        module_name=self.module_list[self.j]
        try:
            self.driver.find_element_by_xpath('//*[@id="content"]/ul/li[{}]/a'.format((self.j)+1)).click()
        except:
            pass
        try:
            self.driver.find_element_by_xpath('//*[@id="myTab"]/li[{}]/a'.format((self.j)+1)).click()
        except:
            pass
        try:
            self.driver.find_element_by_xpath('//*[@class="content"]/div[1]/a[{}]'.format((self.j)+1)).click()
        except:
            pass
        try:
            self.driver.switch_to.frame('app_iframe')
        except:
            pass
        time.sleep(1)
        return module_name