import os
import configparser

class ReadConfigFile(object):
    # def get_value(self):
    root_dir=os.path.dirname(os.path.abspath('.'))
    file_path=root_dir+'/configure/config.ini'

    config=configparser.ConfigParser()
    config.read(file_path,encoding='utf-8-sig')
    Browser=config.get('browserType','browserName')
    login_url=config.get('testUrl','login_url')
    f5_url=config.get('testUrl','f5_url')

    company=config.get('accountMessage','company')
    account=config.get('accountMessage','account')
    password=config.get('accountMessage','password')
# rc=ReadConfigFile()
# print(rc.Browser)