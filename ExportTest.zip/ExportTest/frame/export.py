#coding=utf-8
from ExportTest.frame.is_element_exist import IsElementExist
import time
import datetime
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
class Export(object):
    def __init__(self,driver,logger):
        self.driver=driver
        self.logger=logger
    def old_Export(self,module_name):
        time.sleep(1)
        elements=self.driver.find_elements_by_id('Export')
        number=len(elements)
        for id in range(number):
            text=elements[id].text
            elements[id].click()
            iee=IsElementExist(self.driver,self.logger)
            if iee.is_element_exist_class('explain')==True:
                self.driver.find_element_by_class_name('btn_ok').click()
            else:
                pass
            try:
                #webdriver显示等待：WebDriverWait
                message=WebDriverWait(self.driver,60,3,None).until(EC.presence_of_element_located((By.XPATH,'//*[@id="task_body"]/a')))
                tips=message.text
                self.logger.info(module_name+'-->'+text+':'+tips)
            except:
                self.logger.warning(module_name+'-->'+text+':'+'导出失败或请求超时')
            self.driver.find_element_by_class_name('btn_ok').click()
            time.sleep(1)
    def old_Export_Photo(self,module_name):
        element=self.driver.find_element_by_id('Export_photo')
        text=element.text
        element.click()
        time.sleep(1)
        try:
            self.driver.find_element_by_class_name('photo').click()
            self.driver.find_element_by_class_name('btn_ok').click()
        except:
            pass
        try:
            #webdriver显示等待：WebDriverWait
            message=WebDriverWait(self.driver,60,3,None).until(EC.presence_of_element_located((By.XPATH,'//*[@id="task_body"]/a')))
            tips=message.text
            self.logger.info(module_name+'-->'+text+':'+tips)
        except:
            self.logger.warning(module_name+'-->'+text+':'+'导出失败或请求超时')
        self.driver.find_element_by_class_name('btn_ok').click()
        time.sleep(1)
    def new_Export(self,module_name):
        iee=IsElementExist(self.driver,self.logger)
        #获取模块名
        elements=''
        if iee.is_element_exist_classes('async_export'):
            elements=self.driver.find_elements_by_class_name('async_export')
        elif iee.is_element_exist_id('btn_order_export'):
            elements=self.driver.find_elements_by_id('btn_order_export')
        elif iee.is_element_exist_id('btn_expor_track'):
            elements=self.driver.find_elements_by_id('btn_expor_track')
        else:
            print('未找到导出元素')
        number=len(elements)
        for id in range(number):
            text=elements[id].text
            elements[id].click()
            if iee.is_element_exist_classes('form-radio'):
                for i in self.driver.find_elements_by_xpath('//*[@type="radio"]'):
                    i.click()
                    self.driver.find_element_by_class_name('btn_ok').click()
                    try:
                        #webdriver显示等待：WebDriverWait
                        message=WebDriverWait(self.driver,60,3,None).until(EC.presence_of_element_located((By.XPATH,'//*[@class="ow_open_cont"]/div/span')))
                        tips=message.text
                        self.logger.info(module_name+'-->'+text+':'+tips)
                    except:
                        self.logger.warning(module_name+'-->'+text+':导出失败或请求超时')
                    self.driver.find_element_by_class_name('confirm').click()
                self.driver.find_element_by_class_name('btn_cancel').click()
            elif iee.is_element_exist_classes('x-tree-item-checkbox'):
                time.sleep(2)
                self.driver.find_element_by_xpath('//*[@id="export_user_dept"]/div/div/div[2]/div/div[2]/div[3]/div/i[2]').click()
                t_max=datetime.datetime.now()
                t_min=t_max-datetime.timedelta(days=2)
                max_time=datetime.datetime.strftime(t_max,'%Y-%m-%d')
                min_time=datetime.datetime.strftime(t_min,'%Y-%m-%d')
                self.driver.find_element_by_id('min_time').send_keys(min_time)
                self.driver.find_element_by_id('max_time').send_keys(max_time)
                self.driver.find_element_by_id('btn_add_export_task').click()
                try:
                    #webdriver显示等待：WebDriverWait
                    message=WebDriverWait(self.driver,60,3,None).until(EC.presence_of_element_located((By.XPATH,'//*[@class="ow_open_cont"]/div/span')))
                    tips=message.text
                    self.logger.info(module_name+'-->'+text+':'+tips)
                except:
                    self.logger.warning(module_name+'-->'+text+':导出失败或请求超时')
                self.driver.find_element_by_class_name('confirm').click()
                self.driver.find_element_by_class_name('ow_open_close').click()

            else:
                try:
                    #webdriver显示等待：WebDriverWait
                    message=WebDriverWait(self.driver,60,3,None).until(EC.presence_of_element_located((By.XPATH,'//*[@class="ow_open_cont"]/div/span')))
                    tips=message.text
                    self.logger.info(module_name+'-->'+text+':'+tips)
                except:
                    self.logger.warning(module_name+'-->'+text+':导出失败或请求超时')
                self.driver.find_element_by_class_name('confirm').click()
