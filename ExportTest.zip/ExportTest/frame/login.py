import time
from ExportTest.configure.read_config_file import ReadConfigFile
class Test_Login(object):
    def __init__(self,driver):
        self.driver=driver
    readConfig=ReadConfigFile()
    def test_login(self):
        self.driver.find_element_by_name('company').send_keys(self.readConfig.company)
        self.driver.find_element_by_name('account').send_keys(self.readConfig.account)
        self.driver.find_element_by_name('pass').send_keys(self.readConfig.password)
        self.driver.find_element_by_class_name('login_btn').click()
        time.sleep(3)

