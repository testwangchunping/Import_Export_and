from ExportTest.frame.export import Export
from ExportTest.frame.is_element_exist import IsElementExist
class Juge_Old_Export(object):
    def __init__(self,driver,logger,module_name):
        self.driver=driver
        self.logger=logger
        self.module_name=module_name
    def juge_old_export(self):
        iee=IsElementExist(self.driver,self.logger)
        if iee.is_element_exist_id('Export'):
            Export(self.driver,self.logger).old_Export(self.module_name)
        else:
            pass
        if iee.is_element_exist_id('Export_photo'):
            Export(self.driver,self.logger).old_Export_Photo(self.module_name)
        else:
            pass